$(function () {
    var id_del;
    var now = new Date();
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear() + "-" + (month) + "-" + (day);
    var gb_today = today;
    var str = gb_today;
    var yr = str.substring(0, 4);
    var mt = str.substring(5, 7);
    var dy = str.substring(8, 10);
    fetch_today = "-| " + dy + "/" + mt + "/" + yr;
    $('#date_today').text(fetch_today);

    $(document).on('click', '#close_registration', function (e) {
        e.preventDefault();
        $(location).attr('href', 'registration_mode.html');
    });
    $(document).on('click', '#back_to_session_i', function (e) {
        e.preventDefault();
        parent.history.back();
        return false;
    });
    $(document).on('click', '#del_event', function (e) {
        e.preventDefault();
        $('.popup_foot_right_d').css({
            'float': 'right'
        });
        $('.dialog').css('display', 'block');
    });


    $(document).on('click', '.popup_foot_left_d', function (e) {
        $('.dialog').css('display', 'none');
        $('.popup').css('display', 'block');
    });

    $(document).on('click', '.popup_foot_right_d', function (e) {
        $('.dialog').css('display', 'none');
        $('.popup').css('display', 'block');
    });

    $('.selector').hover(function () {
        $(this).addClass('hover');
    }, function () {
        $(this).removeClass('hover');
    });
    /**
     * Funcion para eliminar la ultima fila de la tabla.
     * Si unicamente queda una fila, esta no sera eliminada
     */
    $(document).on('click', '.del_line', function (e) {
        //tr_id_del_file_1
        e.preventDefault();
        var element_delete = "";
        var id_element = event.target.id;
        var res = id_element.substring(6);
        element_delete = "tr_id_" + res;
        /*alert('id_element: ' + res);*/
        $('#' + element_delete).remove();
    });
});