$(function () {
    $(document).on('click', '#btn_log', function (e) {
        var event_name = $('#log_username').val();
        if (event_name != '') {
            e.preventDefault();
            $.ajax({
                url: 'json/screens.json',
                type: 'POST',
                dataType: 'JSON',
                success: function (data) {
                    var nik = data[0].Name_log;
                }
            })
            $(location).attr('href', 'session_information.html');
        } else {
            $('.popup_foot_left').css('display', 'none');
            $('.popup_foot_right').css({
                'float': 'right'
            });
            $('.popup').css('display', 'block');
    };
    $(document).on('click', '.popup_foot_right', function (e) {
        $('.popup').css('display', 'none');
        $("#log_username").focus();
    });
});

});