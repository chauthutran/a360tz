$(function () {
    var id_del;
    var now = new Date();
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear() + "-" + (month) + "-" + (day);
    var gb_today = today;
    var str = gb_today;
    var yr = str.substring(0, 4);
    var mt = str.substring(5, 7);
    var dy = str.substring(8, 10);
    fetch_today = "-| " + dy + "/" + mt + "/" + yr;
    $('#date_today').text(fetch_today);

    $(document).on('click', '#new_line', function (e) {
        e.preventDefault();
        $('#in_date').val("");
        $('#in_status').val("");
        $('#in_location').val("");

        $('input[type=text]').css({
            'font-size': '100%',
            'padding': '5px',
            'border': '1px solid #bdbdbd',
            'width': '100%',
            'border-radius': '2px',
            'box-sizing': 'border-box'
        });

        $('#in_status').css({
            'width': '100%',
            'font-size': '100%',
            'padding': '5px',
            'border': '1px solid #bdbdbd',
            'border-radius': '2px',
            'box-sizing': 'border-box'
        });

        $('.popup_body').css({
            'height': '220px',
            'box-sizing': 'border-box'
        });


        $('.popup').css({
            'display': 'block',
            'height': '300px',
            'box-sizing': 'border-box'
        });
    });

    $(document).on('click', '.popup_foot_right', function (e) {
        $('.popup').css('display', 'none');
    });
    $(document).on('click', '.popup_foot_right_d', function (e) {
        $('.dialog').css('display', 'none');
        $('.popup').css('display', 'block');
    });

    $(document).on('click', '.popup_foot_left', function (e) {
        $('.popup').css('display', 'none');
        date_val = $('#in_date').val();
        status_val = $('#in_status').val();
        location_val = $('#in_location').val();
        if (date_val != '' & location_val != '') {
            $('.popup').css('display', 'none');
            var date_line = $('#in_date').val();
            var status_line = $('#in_status').val();
            var location_line = $('#in_location').val();
            var del_line = $('#in_line').val();
            var tds = $('#table_sessions tr:first td').length;
            var trs = $('#table_sessions tr').length;
            var id_tr = trs + 1;
            var nuevaFila = "<tr id='tr_id_ia" + id_tr + "' class='selector pointer'>";
            if (tds == 0) tds = 7;
            for (var i = 1; i <= tds; i++) {
                switch (i) {
                    case 1:
                        nuevaFila += '<td>' + date_line + '</td>';
                        break;
                    case 2:
                        nuevaFila += '<td>' + status_line + '</td>';
                        break;
                    case 3:
                        nuevaFila += '<td>' + location_line + '</td>';
                        break;
                }
            }
            nuevaFila += '</tr>';
            $('#table_sessions').prepend(nuevaFila);
        } else {
            $('.popup_foot_left_d').css('display', 'none');
            $('.popup_foot_right_d').css({
                'float': 'right'
            });
            $('.dialog').css('display', 'block');
        }
    });

    $(document).on('click', '.selector', function (e) {
        e.preventDefault();
        var currentId = $(this).attr('id');
        $(location).attr('href', 'event_participants.html');
    });

    $(document).on('click', '#scs', function (e) {
        e.preventDefault();
        dispplay_table = $('#session_ic').css("display");
        if ($('#session_ic').css("display") == 'none') {
            $('#session_ic').show();
            $('#scs_l').text('Closed Sessions');
            $('#scs_i').attr("src", "img/expand.svg");
        } else {
            $('#session_ic').hide();
            $('#scs_l').text('Closed Sessions');
            $('#scs_i').attr("src", "img/contract.svg");
        }
    });
});