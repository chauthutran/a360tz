$(function () {
    var usr_nav = $('#selsr').val();
    if (usr_nav == 'U303120') {
        $('#h1_img').hide();
        $('#session_ic').hide();
        $('body').addClass("bk_pineapple");  
    }
    if (usr_nav == 'U303125') {
        $('.main').hide();
        $('#session_ic').hide();
        $('body').addClass("bk_pineapple");  
    }
    if (usr_nav == 'U5404685') {
        $('body').addClass("bk_mint");
        $('.main').css("display","block");
        $('#header_2').css("width","60%");
    }
});