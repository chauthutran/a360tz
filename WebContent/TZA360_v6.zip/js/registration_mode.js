$(function () {
    var id_del;
    var now = new Date();
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear() + "-" + (month) + "-" + (day);
    var gb_today = today;
    var str = gb_today;
    var yr = str.substring(0, 4);
    var mt = str.substring(5, 7);
    var dy = str.substring(8, 10);
    fetch_today = dy + "/" + mt + "/" + yr;
    $('#date_today').text(fetch_today);


    $('#user_name_log').on('click', function (event) {
        $(location).attr('href', 'session_information.html');
    });

    $(document).on('click', '#mobile', function (e) {
        e.preventDefault();
        $('#in_date').val("");
        $('#in_status').val("");
        $('#in_location').val("");
        $('#mobile_n').dialog('open');
    });
    $(function () {
        $('#mobile_n').dialog({
            autoOpen: false,
            resizable: false,
            height: "auto",
            width: 300,
            show: {
                effect: 'blind',
                duration: 100
            },
            hide: {
                effect: 'drop',
                duration: 60
            },
            modal: true,
            buttons: {
                Search: function () {
                    $(this).dialog('close');
                    $('#confirmation_screen').dialog('open');
                    $('#p_first_and_last_name').text('Sarah Tompson');
                    $('#DoB_DoB').text('09/12/2002 - somewhere in the world');
                    $('#confirmation_screen').dialog('open');
                },
                Cancel: function () {
                    $(this).dialog("close");
                }
            }
        });
    });

    $(document).on('click', '#invitation', function (e) {
        e.preventDefault();
        $('#number_membership').val("");
        $('#voucher').dialog('open');
    });
    $(function () {
        $('#voucher').dialog({
            autoOpen: false,
            resizable: false,
            height: "auto",
            width: 300,
            show: {
                effect: 'blind',
                duration: 100
            },
            hide: {
                effect: 'drop',
                duration: 60
            },
            modal: true,
            buttons: {
                Search: function () {
                    $(this).dialog('close');
                    voucher_number = $('#number_membership').val();
                    if (voucher_number == '12345678') {
                        $(this).dialog("close");
                        $('#p_first_and_last_name').text('Sarah Tompson');
                        $('#DoB_DoB').text('09/12/2002 - somewhere in the world');
                        $('#confirmation_screen').dialog('open');
                    } else {
                        $(this).dialog("close");
                        $('.dialog').dialog('option', 'title', 'No matches found');
                        $('.p_dialog').text("No matches found, please try it with the option [mobile] or [Personal details]. Thank you");
                        $('.dialog').dialog('open');
                    }
                },
                Cancel: function () {
                    $(this).dialog("close");
                }
            }
        });
    });

    $(document).on('click', '#personal_details', function (e) {
        e.preventDefault();
        $('#in_date').val("");
        $('#in_status').val("");
        $('#in_location').val("");
        $('#personal_d').dialog('open');
    });
    $(function () {
        $('#personal_d').dialog({
            autoOpen: false,
            resizable: false,
            height: "auto",
            width: 300,
            show: {
                effect: 'blind',
                duration: 100
            },
            hide: {
                effect: 'drop',
                duration: 60
            },
            modal: true,
            buttons: {
                Search: function () {
                    $(this).dialog('close');
                    voucher_number = $('#number_membership').val();
                    if (voucher_number == '12345678') {
                        $(this).dialog("close");
                        $('#p_first_and_last_name').text('Sarah Tompson');
                        $('#DoB_DoB').text('09/12/2002 - somewhere in the world');
                        $('#confirmation_screen').dialog('open');
                    } else {
                        $(this).dialog("close");
                        $('.dialog').dialog('option', 'title', 'No matches found');
                        $('.p_dialog').text("No matches found, please try it with the option [mobile] or [Personal details]. Thank you");
                        $('.dialog').dialog('open');
                    }
                },
                Cancel: function () {
                    $(this).dialog("close");
                }
            }
        });
    });
    $(function () {
        $('#confirmation_screen').dialog({
            autoOpen: false,
            resizable: false,
            height: "auto",
            width: 300,
            modal: true,
            show: {
                effect: 'blind',
                duration: 100
            },
            hide: {
                effect: 'drop',
                duration: 60
            },
            modal: true,
            buttons: {
                Register: function () {
                    //console.log('Estado:' + selected_option);
                    //if (selected_option === true) {
                    $(this).dialog("close");
                    $('.dialog').dialog('option', 'title', 'Registered!');
                    $('.p_dialog').text("Welcome Sarah to the Session Type + Location");
                    $('.dialog').dialog('open');
                },
                Cancel: function () {
                    $(this).dialog('close');
                }
            }
        });
    });

    $(document).on('click', '#header_3', function (e) {
        e.preventDefault();
        $(location).attr('href', 'registration_mode_2.html');
    });
    $(document).on('click', '#header_32', function (e) {
        e.preventDefault();
        $(location).attr('href', 'registration_mode.html');
    });

    $(document).on('click', '#header_1', function (e) {
        e.preventDefault();
        $('#pin_pass').val("");
        $('#bckend').dialog('open');
    });
    $(document).on('click', '#header_12', function (e) {
        e.preventDefault();
        $('#pin_pass').val("");
        $('#bckend').dialog('open');
    });
    
    $(function () {
        $('#bckend').dialog({
            autoOpen: false,
            resizable: false,
            height: "auto",
            width: 300,
            show: {
                effect: 'blind',
                duration: 100
            },
            hide: {
                effect: 'drop',
                duration: 60
            },
            modal: true,
            buttons: {
                Ok: function () {
                    $(this).dialog('close');
                    pin_number = $('#pin_pass').val();
                    if (pin_number == '1234') {
                        $(this).dialog("close");
                        $(location).attr('href', 'session_information.html');
                    } else {
                        $(this).dialog("close");
                    }
                },
                Cancel: function () {
                    $(this).dialog("close");
                }
            }
        });
    });

    $(document).on('click', '#close_registration', function (e) {
        e.preventDefault();
        $(location).attr('href', 'registration_mode.html');
    });
    $(document).on('click', '#go_to', function (e) {
        e.preventDefault();
        parent.history.back();
        return false;
    });
    $('.selector').hover(function () {
        $(this).addClass('hover');
    }, function () {
        $(this).removeClass('hover');
    });

    $(".dialog").dialog({
        autoOpen: false,
        show: {
            effect: "blind",
            duration: 100
        },
        hide: {
            effect: "drop",
            duration: 60
        }
    });

    $(document).on('click', '.selector', function (e) {
        //tr_id_del_file_1
        e.preventDefault();
        var currentId = $(this).attr('id');
        $('#confirmation_screen').dialog('open');
    });
});