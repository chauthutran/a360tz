$(function () {
    var usr_nav = $('#selsr').val();
    if (usr_nav == 'U303120') {
        $('header').css('margin-top', '0px');
        $('#header_1 img').css('display', 'none');
        $('body').addClass("bk_pineapple");
    }
    if (usr_nav == 'U303125') {
        $('#header_1 img').css('display', 'none');
        $('.main').css('display', 'none');
        $('#session_ic').css('display', 'none');
        $('body').addClass("bk_pineapple");
        $('#event-body').css('width', '50%');
    }
    if (usr_nav == 'U5404685') {
        $('body').addClass("bk_mint");
        $('.main').css("display", "block");
        $('#header_2').css("width", "60%");
    }
    var AvailableWidth = screen.availWidth;
    var AviableHeight = screen.availHeight;
    var height = $(window).height();
    var width = $(window).width();
    $('body').css('height', height);
    $('.contenedor').css('height', '100%');
    alt = $('.form_aside').height();
    $('#session_ic tbody').height(alt / 3.2);
    $('#event_p tbody').height(alt - 100);
    $(window).resize(function () {
        if (height > width) {
            $('.main').hide();
            $('#event-body').css({
                'font-size': '100%',
                'margin-bottom': '2%',
            });
            $('.title_usr').css('font-size', '140%');
            $('footer').css('padding-top', '1%');
            $('aside').css({
                'width': '100%'
            });
            $('.reg_pad').css('padding-top', '10%');
            $('#invitation, #mobile, #personal_details').css({
                'display': 'inline-block',
                'width': alt / 3.5,
                'margin-top': '1%',
                'margin-bottom': '1%',
                'margin-left': '30%'
            });
            $('#session_ic').css('height', '80px');
        }
        if (height < width) {
            $('#event-body').css('font-size', '100%');
            $('.title_usr').css('font-size', '240%');
            $('#invitation, #mobile, #personal_details').css({
                'float': 'left',
                'width': alt / 3.5,
                'margin-top': '5%',
                'margin-bottom': '1%',
                'margin-left': '1%'
            });
            $('.form_aside').css('width', '100%!important');
            if (width <= 640) {
                $('.main').hide();
                $('aside').css({
                    'width': width,
                    'padding': '0%'
                });
                $('#invitation, #mobile, #personal_details').css({
                    'width': alt / 3.5,
                    'margin-left': '6%'
                });
            } else {
                $('.main').show();
                $('main').css({
                    'width': '25%!important',
                    'padding': '0%'
                });
                $('aside').css({
                    'width': 'width',
                    'padding': '0%'
                });
            }
            $('#event-body').css({
                'margin-top': '20px',
                'width': width
            });
            $('.reg_pad').css('padding-top', '0%');
            $('#session_ic').css('width', '50px');
        }
    });

    if (window.orientation == 0) {
        $('.main').hide();
        $('#event-body').css({
            'font-size': '100%',
            'margin-bottom': '2%',
        });
        $('.contenedor').css('height', height);
        $('.title_usr').css('font-size', '140%');
        $('footer').css('padding-top', '1%');
        $('aside').css({
            'width': '100%'
        });
        $('.reg_pad').css('padding-top', '10%');
        $('#invitation, #mobile, #personal_details').css({
            'display': 'inline-block',
            'width': alt / 3.5,
            'margin-top': '1%',
            'margin-bottom': '1%',
            'margin-left': '30%'
        });
        $('#session_ic').css('height', '80px');
    } else {
        $('.contenedor').css('height', height);
        $('#event-body').css('font-size', '100%');
        $('.title_usr').css('font-size', '240%');
        $('#invitation, #mobile, #personal_details').css({
            'float': 'left',
            'width': alt / 3.5,
            'margin-top': '5%',
            'margin-bottom': '1%',
            'margin-left': '10%'
        });
        if (width <= 640) {
            $('.main').hide();
            $('aside').css({
                'width': '100%!important',
                'padding': '0%'
            });
        } else {
            $('.main').show();
            $('main').css({
                'width': '35%!important',
                'padding': '0%'
            });
            $('aside').css({
                'width': '75%!important',
                'padding': '0%'
            });
        }
        $('#event-body').css('margin-top', '20px');
        $('.reg_pad').css('padding-top', '0%');
        $('#session_ic').css('width', '50px');
    }

    $(document).ready(function () {
        $(window).bind("orientationchange", function (event) {
            location.reload();
        });
    });
});
