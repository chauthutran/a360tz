$(function () {
    var id_del;
    var now = new Date();
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear() + "-" + (month) + "-" + (day);
    var gb_today = today;
    var str = gb_today;
    var yr = str.substring(0, 4);
    var mt = str.substring(5, 7);
    var dy = str.substring(8, 10);
    fetch_today = dy + "/" + mt + "/" + yr;
    $('#date_today').text(fetch_today);

    $('#user_name_log').on('click', function (event) {
        $(location).attr('href', 'session_information.html');
    });
    $(document).on('click', '#invitation', function (e) {
        e.preventDefault();
        $('#number_membership').val("");
        $('#voucher input[type=text]').css({
            'font-size': '100%',
            'height': '40px',
            'padding': '5px',
            'border': '1px solid #bdbdbd',
            'width': '100%',
            'border-radius': '2px',
            'box-sizing': 'border-box'
        });
        blockscreen();
        $('#voucher').css('display', 'block');
        $("#number_membership").focus();
    });
    $(document).on('click', '#voucher .popup_foot_left', function (e) {
        voucher_number = $('#number_membership').val();
        if (voucher_number == '12345678') {
            $('#voucher').css('display', 'none');
            $('#p_first_and_last_name').text('Sarah Tompson');
            $('#DoB_DoB').text('09/12/2002 - somewhere in the world');
            $('#confirmation_screen').css({
                'height': '230px'
            });
            $('#confirmation_screen .popup_body').css({
                'height': '150px'
            });
            $('#confirmation_screen select').css({
                'width': '100%',
                'height': '40px',
                'font-size': '100%',
                'box-sizing': 'border-box'
            });
            blockscreen();
            $('#confirmation_screen').css('display', 'block');
        } else {
            $('#voucher').css('display', 'none');
        }

        $('#voucher').css('display', 'none');
        unblockscreen();
    });
    $(document).on('click', '#voucher .popup_foot_right', function (e) {
        voucher_number = $('#number_membership').val();
        if (voucher_number == '12345678') {
            $('#voucher').css('display', 'none');
            $('#p_first_and_last_name').text('Sarah Tompson');
            $('#DoB_DoB').text('09/12/2002 - somewhere in the world');
            $('#confirmation_screen').dialog('open');
            blockscreen();
        } else {
            $('#voucher').css('display', 'none');
        unblockscreen();
        }
    });
    $(document).on('click', '#mobile', function (e) {
        e.preventDefault();
        $('#mobile_number').val("");
        $('#mobile_n input[type=text]').css({
            'font-size': '100%',
            'height': '40px',
            'padding': '5px',
            'border': '1px solid #bdbdbd',
            'width': '100%',
            'border-radius': '2px',
            'box-sizing': 'border-box'
        });
        blockscreen();
        $('#mobile_n').css('display', 'block');
        $("#mobile_number").focus();
    });

    $(document).on('click', '#mobile_n .popup_foot_left', function (e) {
        mobile_number = $('#mobile_number').val();
            $('#mobile_n').css('display', 'none');
            $('#p_first_and_last_name').text('Sarah Tompson');
            $('#DoB_DoB').text('09/12/2002 - somewhere in the world');
            $('#confirmation_screen').css({
                'height': '230px'
            });
            $('#confirmation_screen .popup_body').css({
                'height': '150px'
            });
            $('#confirmation_screen select').css({
                'width': '100%',
                'height': '40px',
                'font-size': '100%',
                'box-sizing': 'border-box'
            });
            blockscreen();
            $('#confirmation_screen').css('display', 'block');
    });
    $(document).on('click', '#mobile_n .popup_foot_right', function (e) {
        $('#mobile_n').css('display', 'none');
        unblockscreen();
    });
    $(document).on('click', '#personal_details', function (e) {
        e.preventDefault();
        $('#first_name').val("");
        $('#last_name').val("");
        $('#mother_name').val("");
        $('#birth_district').val("");
        $('#date_of_birt').val("");
        $('#personal_d input[type=text]').css({
            'font-size': '100%',
            'padding': '5px',
            'border': '1px solid #bdbdbd',
            'width': '100%',
            'height': '40px',
            'border-radius': '2px',
            'box-sizing': 'border-box'
        });
        $('#personal_d').css({
            'height': '380px',
        });
        $('#personal_d .popup_body').css({
            'height': '300px'
        });
        blockscreen();
        $('#personal_d').css('display', 'block');
        $("#first_name").focus();
    });

    $(document).on('click', '#personal_d .popup_foot_left', function (e) {

            $('#personal_d').css('display', 'none');
            $('#p_first_and_last_name').text('Sarah Tompson');
            $('#DoB_DoB').text('09/12/2002 - somewhere in the world');
            $('#confirmation_screen').css({
                'height': '230px'
            });
            $('#confirmation_screen .popup_body').css({
                'height': '150px'
            });
            $('#confirmation_screen select').css({
                'width': '100%',
                'height': '40px',
                'font-size': '100%',
                'box-sizing': 'border-box'
            });
            blockscreen();
            $('#confirmation_screen').css('display', 'block');
    });
    $(document).on('click', '#personal_d .popup_foot_right', function (e) {
        $('#personal_d').css('display', 'none');
        unblockscreen();
    });
    $(document).on('click', '#header_3', function (e) {
        e.preventDefault();
        $(location).attr('href', 'registration_mode_2.html');
    });
    $(document).on('click', '#header_32', function (e) {
        e.preventDefault();
        $(location).attr('href', 'registration_mode.html');
    });
    $(document).on('click', '#header_1', function (e) {
        e.preventDefault();
        $('#bckad .popup_title b').text('Exit');
        $('#bckad .popup_body p').text('To exit registration mode, enter your PIN');
        $("#bckad .popup_body").append("<input type='text' id='pin_pass'>");
        $('#bckad input[type=text]').css({
            'font-size': '100%',
            'height': '40px',
            'padding': '5px',
            'border': '1px solid #bdbdbd',
            'width': '100%',
            'border-radius': '2px',
            'box-sizing': 'border-box'
        });
        blockscreen();
        $('#bckad').css('display', 'block');
    });
    $(document).on('click', '#bckad .popup_foot_left', function (e) {
        pin_number = $('#pin_pass').val();
        if (pin_number == '1234') {
            unblockscreen();
            $('#bckad').css('display', 'none');
            $(location).attr('href', 'session_information.html');
        } else {
            $('#pin_pass').remove();
            unblockscreen();
            $('#bckad').css('display', 'none');
        }
    });
    $(document).on('click', '#bckad .popup_foot_right', function (e) {
        $('#bckad').css('display', 'none');
        $('#pin_pass').remove();
        unblockscreen();
    });
    $(document).on('click', '#confirmation_screen .popup_foot_left', function (e) {
        $('#confirmation_screen').css('display', 'none');
        unblockscreen();
    });
    $(document).on('click', '#confirmation_screen .popup_foot_right', function (e) {
        $('#confirmation_screen').css('display', 'none');
        unblockscreen();
    });
    function blockscreen() {
        $('#invitation').css('pointer-events', 'none');
        $('#mobile').css('pointer-events', 'none');
        $('#personal_details').css('pointer-events', 'none');
        $('#header_1').css('pointer-events', 'none');
    }
    function unblockscreen() {
        $('#invitation').css('pointer-events', 'auto');
        $('#mobile').css('pointer-events', 'auto');
        $('#personal_details').css('pointer-events', 'auto');
        $('#header_1').css('pointer-events', 'auto');
    }
    $(document).on('click', '#close_registration', function (e) {
        e.preventDefault();
        $(location).attr('href', 'registration_mode.html');
    });
    $(document).on('click', '#go_to', function (e) {
        e.preventDefault();
        parent.history.back();
        return false;
    });
    $('.selector').hover(function () {
        $(this).addClass('hover');
    }, function () {
        $(this).removeClass('hover');
    });
    $(document).on('click', '.selector', function (e) {
        e.preventDefault();
        var currentId = $(this).attr('id');
    });
});